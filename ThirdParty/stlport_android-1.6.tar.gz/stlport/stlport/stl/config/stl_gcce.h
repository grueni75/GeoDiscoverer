#ifndef _STLP_WINSCW_H
#define _STLP_WINSCW_H

#define _STLP_COMPILER "GCCE"

//==========================================================

#  define _STLP_LONG_LONG long long

#ifdef _STLP_NO_UNCAUGHT_EXCEPT_SUPPORT
#  undef _STLP_NO_UNCAUGHT_EXCEPT_SUPPORT
#endif

#ifdef _STLP_NO_UNEXPECTED_EXCEPT_SUPPORT
#  undef _STLP_NO_UNEXPECTED_EXCEPT_SUPPORT
#endif

//==========================================================

#endif
