#define _STLP_PLATFORM "Open BSD"
