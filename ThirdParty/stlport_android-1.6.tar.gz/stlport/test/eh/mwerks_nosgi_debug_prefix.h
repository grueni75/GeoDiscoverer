//mwerks_nosgi_debug_prefix.h
#define _STLP_NO_SGI_IOSTREAMS 1
#define _STLP_NO_FORCE_INSTANTIATE 1 // for debugging
#define _STLP_DEBUG_UNINITIALIZED 1 // enable the use of allocation debugging
#define EH_VECTOR_OPERATOR_NEW 1
