/* Simple C++ wrapper around gpsutils.c */

#include "gpsutils.c"
