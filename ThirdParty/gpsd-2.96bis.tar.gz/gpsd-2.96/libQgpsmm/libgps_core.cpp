/* Simple C++ wrapper around libgps_core.c */

#include "libgps_core.c"
